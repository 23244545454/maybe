class ToolCall < ApplicationRecord
  belongs_to :message
end
