class ImpersonationSessionLog < ApplicationRecord
  belongs_to :impersonation_session
end
