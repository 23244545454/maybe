class Valuation < ApplicationRecord
  include Entryable
end
