class Settings::SecuritiesController < ApplicationController
  layout "settings"

  def show
  end
end
