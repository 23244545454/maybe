class OtherLiabilitiesController < ApplicationController
  include AccountableResource
end
