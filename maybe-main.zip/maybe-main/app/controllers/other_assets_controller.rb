class OtherAssetsController < ApplicationController
  include AccountableResource
end
