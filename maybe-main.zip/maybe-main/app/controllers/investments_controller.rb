class InvestmentsController < ApplicationController
  include AccountableResource
end
