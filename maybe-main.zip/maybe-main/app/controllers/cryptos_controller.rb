class CryptosController < ApplicationController
  include AccountableResource
end
