class DepositoriesController <  ApplicationController
  include AccountableResource
end
