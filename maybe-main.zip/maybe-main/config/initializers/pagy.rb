require "pagy/extras/overflow"
require "pagy/extras/array"

Pagy::DEFAULT[:overflow] = :last_page
